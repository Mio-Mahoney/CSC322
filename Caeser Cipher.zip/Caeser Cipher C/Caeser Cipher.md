## Caeser Cipher
---

### Comands
* Encrypt
	Will Encrypt with a key of 5
* Decyrpt
	Will Decrypt with a key of 5
* Encode
	Turns Charecters into Binary
* Decode
	Turns Binary into Charecters
